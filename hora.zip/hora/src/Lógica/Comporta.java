/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

/**
 *
 * @author wcort
 */
public interface Comporta {
    
    public boolean vacia();
    
    
   //Insertar canal a la lista
    
    public void insert(int element);
    
   
    // desplegar 
    
    public int Ver()throws Error;
    
    
    public int BajarCanal() throws Error;
    
    
    
}
