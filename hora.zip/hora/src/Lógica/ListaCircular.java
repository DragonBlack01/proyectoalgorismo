/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lógica;

import javax.sound.sampled.FloatControl;

/**
 *
 * @author wcort
 */
public class ListaCircular implements Comporta {

    Nodo inicio;
    Nodo fin;
    int tama = 0;
    int boton = 0;

    public ListaCircular() {

        inicio = null;
        fin = null;

    }                           //contructor

    @Override
    public boolean vacia() {
        return (tama == 0);

    }

    @Override
    public void insert(int element) {

        Nodo nuevo = new Nodo();

        nuevo.canal = element;

        if (vacia()) {

            inicio = nuevo;
            inicio.siguiente = inicio;
            nuevo.anterior = fin;
            fin = nuevo;

            tama++;

        } else {

            fin.siguiente = nuevo;
            nuevo.siguiente = inicio;
            nuevo.anterior = fin;
            fin = nuevo;
            inicio.anterior = fin;

            tama++;
        }
    }

    @Override
    public int Ver() throws Error {    // subir canales

        Nodo aux = inicio;                  
        System.out.println(" canal " + aux.canal);
        inicio = aux.siguiente;
       
        
        return aux.canal;
    }

    @Override
    public int BajarCanal() throws Error { // bajar canales
       
        Nodo aux = fin;
        System.out.println(" canal " + aux.canal);
        fin = aux.anterior;
        
        return aux.canal;
    }

    
}
