/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentación;

import Lógica.ListaCircular;
import Lógica.Nodo;
import java.util.Scanner;

/**
 *
 * @author wcort
 */
public class Prueba {

    Scanner lectura = new Scanner(System.in);

    public Prueba() {

    }

    public void testeo() {

        ListaCircular Cir = new ListaCircular();

        Cir.insert(1);
        Cir.insert(2);
        Cir.insert(3);
        Cir.insert(4);

        System.out.println("  ");
        Cir.Ver();
        Cir.Ver();
        Cir.Ver();
        Cir.Ver();
        Cir.Ver();
        Cir.Ver();
        System.out.println("  ");

        Cir.BajarCanal();
        Cir.BajarCanal();
        Cir.BajarCanal();
        Cir.BajarCanal();
        Cir.BajarCanal();

    }

}
