/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vetanas;

import java.util.Vector;

/**
 *
 * @author Allan Rodriguez
 */
public class Usuario {

    private String nick;
    private String Contaraseña;
    private String Rango;
    private String estatus;

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public String getContaraseña() {
        return Contaraseña;
    }

    public void setContaraseña(String Contaraseña) {
        this.Contaraseña = Contaraseña;
    }

    public String getEstatus() {
        return estatus;
    }

    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }

  

    public static int verificarUsuarioNuevo(String Usuario) {
        Vector lista = mostrar();
        Usuario obj;
        for (int i = 0; i < lista.size(); i++) {
            obj = (Usuario) lista.elementAt(i);
            if (obj.getNick().equalsIgnoreCase(Usuario)) {
                return i;

            }
        }
        return -1;
    }
    public static  int VerificarLogueo(String Usuario, String Contaraseña){
        Vector lista = mostrar();
        Usuario obj;
        for (int i = 0; i < lista.size(); i++) {
            obj = (Usuario) lista.elementAt(i);
            if (obj.getNick().equalsIgnoreCase(Usuario)&& obj.getContaraseña().equalsIgnoreCase(Contaraseña)) {
                return i;
            }
            
        }
        return -1;
    
    }

    public void setRango(String Rango) {
        this.Rango = Rango;
    }

    public static Vector mostrar() {
        return Lista_Usuario.Mostrar();
    }
}
