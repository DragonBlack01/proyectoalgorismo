/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vetanas;
import java.util.Vector;
/**
 *
 * @author Allan Rodriguez
 */
public class Lista_Usuario {
    private static Vector<Usuario> datos = new Vector<Usuario> ();
    public static void Agregar(Usuario obj){
    datos.addElement(obj);
    }
    public static void Eliminar (int pos){
       datos.removeElementAt(pos);
    }
    public static Vector Mostrar(){
        return datos;
    }

     
}
