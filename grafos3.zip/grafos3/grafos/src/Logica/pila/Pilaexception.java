/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.pila;

/**
 *
 * @author Allan Rodriguez
 */
public class Pilaexception extends RuntimeException {

    public Pilaexception(String error) {
        super(error);
    }
    
    
  
   
    
}

