/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.pila;

/**
 *
 * @author Allan Rodriguez
 */
public class Nodo {
    public Nodo sgte;

    public Object element;

    public Nodo(Object element) {
        this.element = element;
        this.sgte=null;
        
    }

   

    
    
}
