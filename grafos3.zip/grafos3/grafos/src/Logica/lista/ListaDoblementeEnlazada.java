/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.lista;

/**
 *
 * @author rolan
 */
public class ListaDoblementeEnlazada {
    
    private ListaDoblementeEnlazada inicio,fin;
    public ListaDoblementeEnlazada(){
        inicio = fin = null;
    }
    
    //Método para saber si la lista está vacia
    public boolean isEmpty(){
        return inicio == null;
    }
    
    //Método para agregar los nodos al final
    public void lastInList(int el){
        if (!isEmpty()) {
            
        }
    }
}
