/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.lista;

/**
 *
 * @author rolan
 */
public interface Lista {
    
    //Devuelve el numero de elementos de la lista
    public int getSize();
    
    //Anular la lista
    public void cancel();
    
    //Me devuelve true si la lista está vacía
    public boolean isEmpty();
    
    //Insertar elementos a la lista
    public void insert(Object element);
    
    //devuelve la posicion del elemento que estamos buscando
    public int getPosition(Object element) throws ListaException;
    
    //elimina un valor de la lista enlazada
    public void delete(Object element) throws ListaException;
    
    //Devuelve true si existe el elemento buscado
    public boolean exists(Object element) throws ListaException;
    
    //busca el elemento y lo actualiza
    public void edit(Object elementToSearch,Object valueToUpdate) throws ListaException;
    
    //devuelve el primer valor de la lista enlazada
    public Object firstInList() throws ListaException;
    
    //devuelve el ultimo valor de la lista enlazada
    public Object lastInList() throws ListaException;
    
    //Ordena la lista
    public void orderList();
    
    
    
}
