
package Logica.lista;


public class Nodo {
 
    //atributos
    public Object element; //guarda lo que ocupemos en el nodo
    public Nodo sgte,ant; //apuntador/enlace al siguiente nodo

    public Nodo(Object element) {
        this.element = element;
    }
    
}
