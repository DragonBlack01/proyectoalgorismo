/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.cola;

/**
 *
 * @author Allan Rodriguez
 */
public class Cola_arreglo implements Cola {
    private Object C[];
    private int anterior,posterior;
    
   

    public Cola_arreglo(int n) {
      C = new Object[n];
      this.anterior= this.posterior= n-1;
      
    }

    @Override
    public void encolar(Object element) {
       C[posterior]= element;
       posterior--;
       
       
    }

    @Override
    public boolean isEmpty() {
        if(posterior== anterior)
            return true;
        else
            return false;
        
        }

    @Override
    public Object desencolar() throws ColaException{
     posterior++;
     Object aux = C[anterior];
     for(int i = anterior; i>0; i--){
         C[anterior]=C[anterior-1];
     } 
     return aux;
     
    }

    @Override
    public int getSize() {
       return anterior- posterior ;}
    
    public void destroy(){
       
       anterior=posterior=-1;
        
                
    }
    
    @Override
    public Object frente() {
       
       
        
        return  C[anterior];
        
       
    
    }
    public String toString(){
        
        
        String impresionpila ="";
        
        
        for(int i = 0; i<= anterior; i++){
            impresionpila+="valor cola: "+C[i]+ "\n";
        }
        return impresionpila;

    }

    
        
        
    
}
