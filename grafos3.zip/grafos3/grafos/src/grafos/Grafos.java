/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafos;

//import presentacion.pruebas;
import presentacion.PruebaLista;


/**
 *
 * @author Allan Rodriguez
 */
public class Grafos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     //pruebas v = new pruebas(15);
     PruebaLista p = new PruebaLista(9);
     //v.test();
     p.test();
     
     
     

    }
    
}
