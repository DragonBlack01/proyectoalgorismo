/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logico.grafo;
import Logica.lista.ListaEnlazada;
/**
 *
 * @author Allan Rodriguez
 */
public class vertice {
    
    Object element;
    boolean visitado;
    boolean destino;
    ListaEnlazada listaArista,listaPesos;
    
    

    public vertice(Object elemento) {
        
        this.element=elemento;
        this.visitado=false;
        listaArista= new ListaEnlazada();
        listaPesos= new ListaEnlazada();
        
        
        
    }


        
    }

    
    
    
    

