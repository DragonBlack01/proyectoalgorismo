/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logico.grafo;

/**
 *
 * @author Allan Rodriguez
 */
public interface Grafo {
    
    public void anular();
    public boolean isEmpty ();
    public int getSize  ();
    public void agregarVertice(Object element);
    public boolean existeVertice  (Object element);
    public void agregarArista(Object v1,Object v2);
    public boolean existeArista  (Object v1,Object v2);
    public void agregarPeso (Object v1,Object v2,Object peso);
    public String dfs ();
    public String bfs ();
    
    
    
    
}
