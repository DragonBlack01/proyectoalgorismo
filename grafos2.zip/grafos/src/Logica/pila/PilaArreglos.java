/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.pila;

/**
 *
 * @author Allan Rodriguez
 */
public class PilaArreglos implements pila{
    
    private Object P[];
    
    private int tope;

    public PilaArreglos(int n) {
       if(n<=0)
           System.exit(0);
       
       P= new Object [n];
       tope=-1;
       
               
       
    }

    @Override
    public int getSize() {
        return tope+1;
        
                
        }

    @Override
    public boolean isEmpty() {
        return tope <0;
        }

    @Override
    public Object top() throws Pilaexception {
        if (isEmpty())
            throw new  Pilaexception ("Pila vacia , no hay tope");
        
        
        return P[tope];
        
        
       }

    @Override
    public Object pop() {
         if (isEmpty())
            throw new  Pilaexception ("Pila vacia , no hay tope");
        return P[tope--];
         }

    @Override
    public void push(Object element) {
        if (getSize()== P.length)
            throw new  Pilaexception ("Pila llena");
        
       P[++tope]= element;
       
        
    }
    public String toString(){
        
        
        String impresionpila ="";
        
        
        for(int i = 0; i<= tope; i++){
            impresionpila+="valor pilado: "+P[i]+ "\n";
        }
        return impresionpila;
    }
    
}
