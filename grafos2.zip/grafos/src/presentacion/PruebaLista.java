/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;
import logico.grafo.GrafoListaEnlazada;

/**
 *
 * @author Allan Rodriguez
 */
public class PruebaLista {
    
    GrafoListaEnlazada la;
    
    public PruebaLista( int n){
        this.la =new GrafoListaEnlazada (n);
        
    }
    public void test (){
        
    la.agregarVertice("San Jose");
    la.agregarVertice("Alajuela");
    la.agregarVertice("Heredia");
    la.agregarVertice("Limon");
    la.agregarVertice("Guanacaste");
    la.agregarVertice("Cartago");
    la.agregarVertice("Puntarenas");
    la.agregarVertice("Nicoya");
    
    la.agregarArista("San Jose","Alajuela");
    la.agregarArista("Heredia","Limon");
    la.agregarArista("Guanacaste","Cartago");
    la.agregarArista("Alajuela","Heredia");
    la.agregarArista("San Jose","Guanacaste");
    la.agregarArista("Puntarenas","Nicoya");
    
   
    la.agregarPeso("San Jose","Alajuela",10);
    la.agregarPeso("Heredia","Limon",60);
    la.agregarPeso("Guanacaste","Cartago",160);
    la.agregarPeso("Alajuela","Heredia",41);
    la.agregarPeso("San Jose","Guanacaste",150);
    la.agregarPeso("Puntarenas","Nicoya",15);
    
    System.out.println(la.toString());
   
  
   
   
     
        
     
     
    
   
    }
}
