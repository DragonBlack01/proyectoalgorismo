/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logico.grafo;

import Logica.cola.ColaEnlazada;
import Logica.pila.Pila_enlazada;

/**
 *
 * @author Allan Rodriguez
 */
public class GrafoListaEnlazada implements Grafo{
    
     private vertice [] vertices;
     
    
    private int contador;
    Pila_enlazada pila;
    ColaEnlazada cola;
    
    Object [][]rutas;
    private int n;
    
    
    
    public GrafoListaEnlazada(int n) {
      if(n<0)
            System.exit(0);
        this.n= n;
        this.contador = 0;  
        vertices= new vertice[n];
        
        pila = new Pila_enlazada();
        cola = new ColaEnlazada();
        
        rutas= new Object [2][2];      
        
        
        
        
    }
     public void GrafoListaEnlazada(){
        
        for(int i= 0; i< n; i++){
            for(int j= 0; j< n; j++){
             rutas[i][j]=0;
            }
        }
     }
             
    @Override
    public void anular() {
           for(int i= 0; i< n; i++){
            vertices [i]= null;
            contador =0;    
        } 
    }

    @Override
    public boolean isEmpty() throws Exception {
           return contador==0;}

    @Override
    public int getSize() throws Exception {
        if (isEmpty())
            throw new Exception("El grafo no existe");
                
        return contador;
    }

    @Override
    public void agregarVertice(Object element) {
      
       if(contador<=vertices.length){
   
       }
        vertices [contador++] = new vertice(element);
       
    }

    @Override
    public boolean existeVertice(Object element) throws Exception {
       if (isEmpty())
            throw new Exception("El grafo no existe");
       for(int i= 0; i< contador; i++){
              if(vertices[i].element.equals(element))
                  return true;
              
          }
        return false;
          
    }

    @Override
    public void agregarArista(Object v1, Object v2) {
        if(!existeVertice(v1)||!existeVertice(v2))
            throw new Exception ("Uno o ambos vertices no existe");
        
        vertices[getPosicion(v1)].listaArista.insert(v2) ;
        vertices[getPosicion(v2)].listaArista.insert(v1) ;
    }

    @Override
    public boolean existeArista(Object v1, Object v2) throws Exception {
          if (isEmpty())
            throw new Exception("El grafo no existe");
          if ( vertices[getPosicion(v1)].listaArista.exists(v2))
             return true;
         return false;
          
    }

    @Override
    public void agregarPeso(Object v1, Object v2, Object peso) {
        if(!existeArista(v1,v2))
              throw new Exception ("No existe arista entre"+v1+" y la arista "+v2 );
    
        vertices[getPosicion(v1)].listaPesos.insert(peso);
        vertices[getPosicion(v2)].listaPesos.insert(peso);
        
        }

    @Override
    public String dfs() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String bfs() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  
        private int getPosicion (Object element){
          for(int i= 0; i< contador; i++){
              if(vertices[i].element.equals(element)){
                  return i;
              }
                  
          }
        return -1;
    }
        public void agregarAristaYPeso(Object v1,Object v2,Object peso) throws  Exception{
        vertices[getPosicion(v1)].listaArista.insert(v2) ;
        vertices[getPosicion(v2)].listaArista.insert(v1);
        vertices[getPosicion(v1)].listaArista.insert(peso) ;
        vertices[getPosicion(v2)].listaArista.insert(peso);
        }

    public String toString() {
       String salida = "INFORMACION DEL GRAFO\n";
              salida += "Grafo con Matriz de Lista\n";
              salida+= "---------------\n";
              
       for(int i = 0; i< contador; i++){
           salida+="El vertice en la posision: "+i+" es:"+vertices[i].element+"\n";
           
           
       }
     salida+="Arista y Pesos del grafo \n\n";
     for(int i= 0; i< contador; i++){
         salida+="Vertice: "+vertices[i].element+"\n";
         salida+= "-----Arista: "+ vertices[i].listaArista.toString()+"\n";
         salida+= "-----Peso: "+ vertices[i].listaPesos.toString()+"\n";
         salida+="-------------------------------\n\n";
             }
             
         salida+="\n";
     
        
    
       return salida;
    }
    
    
}
