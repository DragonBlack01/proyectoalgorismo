/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion;
import Logico.Lista;


public class prueba {
    Lista lista1;
    
  public prueba() {
        lista1 = new Lista();  
        
    
}
   public void test(){
       
    lista1.insert(8);
    lista1.insert(67);
    lista1.insert(2);
    lista1.insert(10);
    lista1.insert(9);
    lista1.insert(8);
    lista1.insert(5);
    lista1.insert(6);
    lista1.insert(38);
    lista1.insert(50);
    lista1.insert(14);
    System.out.println("La lista tiene: "+lista1.getSize()+" elementos");
    lista1.delete(6);
 
    System.out.println("La lista tiene: "+lista1.getSize()+" elementos");
    System.out.println("El canal buscado esta en la posicion  "+lista1.getPosition(10));
    System.out.println("La lista tiene: "+lista1.getSize()+" elementos");
    System.out.println(lista1.toString());  
    System.out.println("---------------");
    System.out.println("canal buscado: "+lista1.exists(10));
    System.out.println("El primer canal de la lista es  :"+lista1.firstInList());
    System.out.println("El ultimo canal de la lista es  :"+lista1.lastInList());
    lista1.cancel();
   
    
   
   }
}
