/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentacion;
import Logico.Lista;


public class prueba {
    Lista lista1;
    
  public prueba() {
        lista1 = new Lista();  
        
    
}
   public void test(){
       
    lista1.insert(1);
    lista1.insert(67);
    lista1.insert(2);
    lista1.insert(10);
    lista1.insert(9);
    lista1.insert(8);
    lista1.insert(0);
    lista1.insert(6);
    lista1.insert(38);
    lista1.insert(50);
    lista1.insert(14);
    System.out.println("se ingresaron "+lista1.getSize()+" canales");
    
    
    
    
       
   }
}
