/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */
public class Lista implements Interfaz{
    Nodo inicio,fin;

    public Lista() {
        inicio = fin = null;
        
        
        
    }
    

    @Override
    public int getSize() {
     
       if(isEmpty())
            return 0; 
        
            Nodo aux = inicio;
            int contador = 0;
            
            while(aux != null){
                contador++;
                aux = aux.sgte;
            }
            
            
        return contador;
       
    
        
    }
        
      
    @Override
    public void cancel() {
        if(isEmpty()){
            throw  new Exception("No podemos borrar lista, porque la lista está vacía");
        
        }else{
            Nodo aux = inicio;
             Nodo nodoAnterior = null;
             
             
            while(aux.sgte != null){
                nodoAnterior = aux; 
                aux = aux.sgte;
                 inicio = null;
                nodoAnterior.sgte = aux.sgte;
            }
            
           
            System.out.println("Lista se ha eliminado ");
        }
    
         
        
        
    }

    @Override
    public boolean isEmpty() {
        return inicio==null;
    }

    @Override
    public void insert(Object element) {
       Nodo aux = inicio;
        Nodo nuevoElemento = new Nodo(element);
    
        
        if(isEmpty()){
            inicio = nuevoElemento;
            System.out.println("Se ingreso: "+element+" a la lista enlazada");
        }else{
            
            while(aux.sgte != null){
                aux = aux.sgte;
            }
            
           
            aux.sgte = nuevoElemento;
            System.out.println("Se ingreso: "+element+" a la lista enlazada");
        }
    }

    @Override
    public int getPosition(Object element) throws Exception {
        
        
        if(isEmpty())throw new Exception("No puedo buscar la posicion porque la lista esta vacia");
        
      Nodo aux = inicio;
      int posicion = 1;
        
     while(aux != null){
         if(aux.element.equals(element)){
            return posicion;
            
            }
         aux = aux.sgte;
          posicion++;
        }
          
        
        return 0;
    
        
    }

    @Override
    public void delete(Object element) throws Exception {
       if(isEmpty()){
            throw  new Exception("No podemos borrar valores, porque la lista está vacía");
        }
        
        Nodo aux = inicio;
        Nodo nodoAnterior = null;
       
       
        if(inicio.element.equals(element)){
            inicio = inicio.sgte;
            System.out.println("Se ha eliminado el primer elemento de la lista");
        }
        else{
        
            
            
            while(aux.sgte != null && !aux.element.equals(element)){ 
                nodoAnterior = aux; 
                aux = aux.sgte;
            }
            if(aux.element.equals(element)){
                nodoAnterior.sgte = aux.sgte;
            }
            System.out.println("Se borro un elemento dentro de la lista(pero no el primero)");
        }
        System.out.println("Se eliminó el nodo: "+element);
    }

    @Override
    public boolean exists(Object element) throws Exception {
       if(isEmpty()){
            throw  new Exception("No podemos borrar valores, porque la lista está vacía");
        }
        
        Nodo aux = inicio;
        Nodo nodoAnterior = null;
       
       
        if(inicio.element.equals(element)){
            return true;
            
           
           
       }else{
            while(aux.sgte != null && !aux.element.equals(element)){
             
                nodoAnterior = aux; 
                aux = aux.sgte;
        }
            
        }if(aux.element.equals(element)){//ya lo encontró, ocupamos borrarlo 
                return true;
            }
        
      return false;
     
       }


    @Override
    public void edit(Object elementToSearch, Object valueToUpdate) throws Exception {
         if(isEmpty()){
            throw  new Exception("No podemos modidicar canales, porque la lista está vacía");
        }
        
       Nodo aux = inicio;
       
        Nodo nodoAnterior = null;
       
       
        if(inicio.element.equals(elementToSearch)){
          inicio.element= inicio.element.equals(valueToUpdate);
           
        }
        else{
        
            
            
            while(aux.sgte != null && !aux.element.equals(elementToSearch)){ 
                nodoAnterior = aux; 
                aux = aux.sgte;
            }
            if(aux.element.equals(elementToSearch)){
            aux.element= aux.element.equals(valueToUpdate);
             
            }
            System.out.println("Se modifico canal : "+elementToSearch+" por el canal "+valueToUpdate);
        }
        
        
      
    }


    @Override
    public Object firstInList() throws Exception {
       if(isEmpty()){
            throw  new Exception("lista está vacía");}
 

        
       return inicio.element;
        
       }

    @Override
    public Object lastInList() throws Exception {
       Nodo aux = inicio; 
        Nodo aux2 = inicio;
       
        
        int cantidadElementos = getSize();
        int contador = 0;        
        
        
        while(aux2!=null){  
            while(aux!=null && contador<cantidadElementos-1){
               
                    
                    aux.element = aux.sgte.element;
                    
                
                contador++;
                aux = aux.sgte;
            }
        aux = inicio;
        aux2 = aux2.sgte;
        contador = 0;
        }
        return aux.element;
    }
       
       
    
    
    
    
   

    @Override
    public void orderList() {
        Nodo aux = inicio; 
        Nodo aux2 = inicio;
        int temporal = 0;
        
        int cantidadElementos = getSize();
        int contador = 0;        
        
        
        while(aux2!=null){  
            while(aux!=null && contador<cantidadElementos-1){
                if((int)aux.element > (int)aux.sgte.element){
                    temporal = (int)aux.element;
                    aux.element = aux.sgte.element;
                    aux.sgte.element = temporal;
                }
                contador++;
                aux = aux.sgte;
            }
        aux = inicio;
        aux2 = aux2.sgte;
        contador = 0;
        }
    }
    
    public String toString(){
    String resultado = "\n------------------------\nINFORMACION DE LA LISTA: ";
    
    Nodo aux = inicio;
    
        while (aux != null) {
            resultado += "\nNodo con valor: "+aux.element;
            aux = aux.sgte;
        }
    
    return resultado;
    
    }
}
