/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */
public class Lista implements Interfaz{
    Nodo inicio,fin;

    public Lista() {
        inicio = fin = null;
        
        
    }
    

    @Override
    public int getSize() {
       if(isEmpty()){
            return 0; //no hay valores / esta vacia la lista
       }else{
            Nodo aux = inicio;//con aux vamos a poder recorrer la lista
            int contador = 0;//conteo del numero de elementos de la lista
            
            while(aux != inicio){
                contador++;
                aux = aux.sgte;
            }//while
            
            /*
           Inicio = [2] --> [X] --> [8] --> [1] --> [R] -> NULL 
                                                            aux  
            contador=5
            */ 
        return contador;

        
           
        
    }
    }
        
      
    @Override
    public void cancel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isEmpty() {
        return inicio==null;
    }

    @Override
    public void insert(Object element) {
        Nodo aux = inicio;
        Nodo nuevoNodo = new Nodo(element);
  
        if(inicio == null){
            inicio = fin = nuevoNodo;
        }
        
        else{
        
      
            while(aux != fin){
                aux = aux.sgte;
            }
            aux.sgte = nuevoNodo;
            nuevoNodo.ant = aux;
        }
        
        inicio.sgte = fin;
        fin.sgte = inicio;
    }

    @Override
    public int getPosition(Object element) throws Exception {
        
        
        if(isEmpty())throw new Exception("No puedo buscar la posicion porque la lista esta vacia");
        
         Nodo aux = inicio;
        int posicion = 1;
        
        while(aux != null){
            if(aux.element.equals(element)){
               return posicion;
            }
            aux = aux.sgte;
            posicion++;
        }
          
        
        return 0;
    
        
    }

    @Override
    public void delete(Object element) throws Exception {
       if(isEmpty()){
            throw  new Exception("No podemos borrar valores, porque la lista está vacía");
        }
        
        Nodo aux = inicio;
        Nodo nodoAnterior = null;
       
       
        if(inicio.element.equals(element)){
            inicio = inicio.sgte;
            System.out.println("Se ha eliminado el primer elemento de la lista");
        }
        else{
        
            
            
            while(aux.sgte != null && !aux.element.equals(element)){ 
                nodoAnterior = aux; 
                aux = aux.sgte;
            }
            if(aux.element.equals(element)){
                nodoAnterior.sgte = aux.sgte;
            }
            System.out.println("Se borro un elemento dentro de la lista(pero no el primero)");
        }
        System.out.println("Se eliminó el nodo: "+element);
    }

    @Override
    public boolean exists(Object element) throws Exception {
     Nodo aux=inicio;
         while((aux.sgte!=inicio) && (!(aux.element.equals(element))))
                   aux=aux.sgte;
         return aux.element.equals(element);
       }


    @Override
    public void edit(Object elementToSearch, Object valueToUpdate) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object firstInList() throws Exception {
        return inicio;
    }

    @Override
    public Object lastInList() throws Exception {
       return fin;
    }

    @Override
    public void orderList() {
        Nodo aux = inicio; //movernos por la lista
        Nodo aux2 = inicio;
        int temporal = 0;
        
        int cantidadElementos = getSize();
        int contador = 0;        
        
       
        while(aux2!=null){  
            while(aux!=null && contador<cantidadElementos-1){
                if((int)aux.element > (int)aux.sgte.element){
                    temporal = (int)aux.element;
                    aux.element = aux.sgte.element;
                    aux.sgte.element = temporal;
                }
                contador++;
                aux = aux.sgte;
            }
        aux = inicio;
        aux2 = aux2.sgte;
        contador = 0;
        }
    }
    
    public String toString(){
    String resultado = "\n------------------------\nINFORMACION DE LA LISTA: ";
    
    Nodo aux = inicio;
    
        while (aux != null) {
            resultado += "\nNodo con valor: "+aux.element;
            aux = aux.sgte;
            aux.ant = aux;
        }
    
    return resultado;
    }
}
