/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */


public class Nodo {
    
   public Object element; //guarda lo que ocupemos en el nodo
  public Nodo sgte,ant; //apuntador/enlace al siguiente nodo

    public Nodo(Object element) {
        this.element = element;
    }
  
    
}
