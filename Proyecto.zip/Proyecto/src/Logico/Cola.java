/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */
public interface Cola {
    public void encolar(Object element);
    public boolean isEmpty();
    public Object desencolar() throws Exception;
     public int getSize();
    public Object frente ()throws Exception;
    
  
    
    
    
}
