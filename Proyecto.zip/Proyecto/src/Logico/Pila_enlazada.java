/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */
public class Pila_enlazada implements pila {
    
    
   private Nodo tope;
   private  int contador;
    private Object element;

    public Pila_enlazada() {
        tope= null;
       contador= 0;
    }
    
     
     @Override
    public int getSize() {
        
         return contador;
         
    }

    @Override
    public boolean isEmpty() {
    
       return tope== null;
    }

    @Override
    public Object top() throws Exception {
       if (isEmpty())
            throw new  Exception ("Pila vacia , no hay tope");
        
        return tope;
        }

    @Override
    public Object pop() throws Exception {
     Nodo nuevoNodo = new Nodo(element);
    
    if(tope== null){
        tope= nuevoNodo;
    }else{
    nuevoNodo.sgte = tope;
    
    tope= nuevoNodo;
    }
    contador --;
    
    
       return null;
    
}

    @Override
    public void push(Object element) {
    Nodo nuevoNodo = new Nodo(element);
    
    if(tope== null){
        tope= nuevoNodo;
    }else{
    nuevoNodo.sgte = tope;
    
    tope= nuevoNodo;
    }
    contador ++;
    
    
    
    
    
    }
    public String toString(){
     Nodo aux = tope;
        
        while(aux != null){
            System.out.println("|\t" + aux.element + "\t|");
            System.out.println("-----------------");
            aux = aux.sgte;
            
            
            
        }
       return null;
        
        
     
    }
    public void destroy(){
        tope=null;
        contador= 0;
        
        
    }

    }

   

