/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logico;

/**
 *
 * @author Allan Rodriguez
 */
public interface Interfaz {
    
    
     public int getSize();
    
    //Anular la lista
    public void cancel();
    
    //Me devuelve true si la lista está vacía
    public boolean isEmpty();
    
    //Insertar elementos a la lista
    public void insert(Object element);
    
    //devuelve la posicion del elemento que estamos buscando
    public int getPosition(Object element) throws Exception;
    
    //elimina un valor de la lista enlazada
    public void delete(Object element) throws Exception;
    
    //Devuelve true si existe el elemento buscado
    public boolean exists(Object element) throws Exception;
    
    //busca el elemento y lo actualiza
    public void edit(Object elementToSearch,Object valueToUpdate) throws Exception;
    
    //devuelve el primer valor de la lista enlazada
    public Object firstInList() throws Exception;
    
    //devuelve el ultimo valor de la lista enlazada
    public Object lastInList() throws Exception;
    
    //Ordena la lista
    public void orderList();
}
