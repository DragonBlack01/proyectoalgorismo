/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logico.grafo;



/**
 *
 * @author Allan Rodriguez
 */
public class GrafoAdyancencia implements Grafo {
    private vertice [] vertices;
    private Object [][] matrizAdyacencia;
    private int contador;
    private int n;

    public GrafoAdyancencia(int n) {
        if(n<0)
            System.exit(0);
        this.n= n;
        this.contador = 0;
        
        vertices = new vertice[n];
        matrizAdyacencia = new Object [n][n];
        
       inicializarMatrizdeAdyacencia();
        
        
    }

    
    public void inicializarMatrizdeAdyacencia(){
        
        for(int i= 0; i< n; i++){
            for(int j= 0; j< n; j++){
              matrizAdyacencia[i][j]=0;
              
              
                
            }
            
        }
    }

    @Override
    public void anular() {
        for(int i= 0; i< n; i++){
            vertices [i]= null;
            contador =0;
             inicializarMatrizdeAdyacencia();
        }
        }

    @Override
    public boolean isEmpty() {
       
        return contador==0;
        
        
       }

    @Override
    public int getSize() {
        return contador;
    }

    @Override
    public void agregarVertice(Object element) {
       if(contador<=vertices.length){
         ;
           
       }
       
       vertices [contador++] = new vertice(element);
       
       
    }

    @Override
    public boolean existeVertice(Object element) {
        if(isEmpty())
            throw new Exception ("no vertices ");
          for(int i= 0; i< contador; i++){
              if(vertices[i].element.equals(element))
                  return true;
              
          }
        return false;
          
       }

    @Override
    public void agregarArista(Object v1, Object v2) {
        if(!existeVertice(v1)||!existeVertice(v2))
            throw new Exception ("Uno o ambos vertices no existe");
        
        matrizAdyacencia[getPosicion(v1)][getPosicion(v2)]= 1;
        matrizAdyacencia[getPosicion(v2)][getPosicion(v1)]= 1;
        
        
        
        }
     @Override
     public boolean existeArista  (Object v1,Object v2)throws Exception{
        
        if(isEmpty())
              throw new Exception ("No hay grafo en el cual buscar");
          
        if ( matrizAdyacencia[getPosicion(v1)][getPosicion(v2)]!=(Object)0)
             return true;
         
        
        
      return false;
         
         
     }

    @Override
    public void agregarPeso(Object v1, Object v2, Object peso) {
        
    if(!existeArista(v1,v2))
              throw new Exception ("No existe arista entre"+v1.toString()+" y la arista "+v2.toString() );
    
   matrizAdyacencia[getPosicion(v1)][getPosicion(v2)]= peso;
   matrizAdyacencia[getPosicion(v2)][getPosicion(v1)]= peso;
    }

    @Override
    public String dfs() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String bfs() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    private int getPosicion (Object element){
          for(int i= 0; i< contador; i++){
              if(vertices[i].element.equals(element)){
                  return i;
              }
                  
          }
        return -1;
    }

    public String toString() {
       String salida = "INFORMACION DEL GRAFO\n";
              salida += "Grafo con Matriz de Adyacenci\n";
              salida+= "---------------\n";
              
       for(int i = 0; i< contador; i++){
           salida+="El vertice en la posision: "+i+" es:"+vertices[i].element+"\n";
           
           
       }
     salida+="Arista y Pesos del grafo \n";
     for(int i= 0; i< contador; i++){
         for(int j= 0; j< contador; j++){
             if(matrizAdyacencia[i][j]!= (Object)0){
                 salida+= vertices[i].element+"<--------->"+ vertices[j].element+"\n";
             if(matrizAdyacencia[i][j]!= (Object)1){
                 salida+= "Peso:"+matrizAdyacencia[i][j]+" \n";    
             }
             
         }
     }
        
    }
       return salida;
    }
    
    public void Djikstra(Object origen,Object destino ){
       for(int i= 0; i< 0; i++){
         for(int j= 0; j< 0; j++){
             if(matrizAdyacencia[i][j]!= (Object)0){
                origen= vertices[i].element.equals(origen);
                destino=vertices[j].element.equals(destino);
             if(matrizAdyacencia[i][j]!= (Object)1){
                 destino= "Peso:"+matrizAdyacencia[i][j]+" \n";    
             }
             System.out.println("La ruta mas corta entre  origen y destino es: "+matrizAdyacencia[i][j] );
             }
         }
       }
    }
}
        
       
          
    
 

    
    
    

