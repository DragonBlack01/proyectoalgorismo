/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.lista;

/**
 *
 * @author rolan
 */
public class ListaCircularDoblementeEnlazada implements Lista{
    
    //Atributos
    Nodo inicio,fin;

    public ListaCircularDoblementeEnlazada() {
    
        inicio = fin = null;
    
    }//fin Constructor

    @Override
    public int getSize() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void cancel() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean isEmpty() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void insert(Object element) {
        
        Nodo aux = inicio;//permite moverme por la lista
        Nodo nuevoNodo = new Nodo(element);
        
        //Caso 1: Cuando la lista está vacía
        if(inicio == null){
            inicio = fin = nuevoNodo;
        }
        //Caso 2: Cuando la lista no está vacía
        else{
        
            /*
            Lista Enlazada = [2] --> [5] --> [7] --> [11] --> NULL
                            inicio
            Lista Doblemente Enlazada = [2]<-- --> [5]<-- --> [7]<-- --> [11]<-- --> NULL
                            inicio
            Lista Circular Enlazada =  [2]=inicio
                                fin=[11]  [5] 
                                       [7]
            Lista Circular Doblemente Enlazada =  [2]=inicio
                                          fin=[11]  [5] 
                                                  [7]
                                           Inicio.ant = fin
                                           fin.sgte = inicio
            */
            
            /*
                [2] = inicio   
         fin=[7]     [5]
        [21]            [8]
            [80]     [1]
                [4]
            
            fin=[7]<--->[2]=inicio
            
            
            */
            
            while(aux != fin){
                aux = aux.sgte;//nos movemos al siguiente nodo
            }//fin del while
            aux.sgte = nuevoNodo;
            nuevoNodo.ant = aux;//hacemos el doble enlace
        }
        //realizamos el enlace circular
        inicio.sgte = fin;
        fin.sgte = inicio;
    
    }//Fin del metodo insertar

    @Override
    public int getPosition(Object element) throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(Object element) throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean exists(Object element) throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void edit(Object elementToSearch, Object valueToUpdate) throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object firstInList() throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object lastInList() throws ListaException {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void orderList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
