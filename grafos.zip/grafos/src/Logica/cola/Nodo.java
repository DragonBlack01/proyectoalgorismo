/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.cola;

/**
 *
 * @author Allan Rodriguez
 */
public class Nodo {
    public Nodo posterior;

    public Object element;
    Nodo sgte;

    public Nodo(Object element) {
        this.element = element;
        this.posterior=null;
    }
}
