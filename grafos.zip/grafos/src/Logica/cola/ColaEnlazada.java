/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.cola;

/**
 *
 * @author Allan Rodriguez
 */
public class ColaEnlazada implements Cola {
    
     private Nodo posterior;
   private  int contador;
    private Object element;
   
   
   
   public ColaEnlazada(){
       
       posterior= null;
       contador= 0;
   }

    @Override
    public void encolar(Object element) {
        Nodo nuevoNodo = new Nodo(element);
    
    if(posterior== null){
        posterior= nuevoNodo;
    }else{
    nuevoNodo.sgte = posterior;
    
    posterior= nuevoNodo;
    }
    contador ++;}

    @Override
    public boolean isEmpty() {
        return posterior== null;
          }

    @Override
    public Object desencolar() throws ColaException {
        Nodo nuevoNodo = new Nodo(element);
    
    if(posterior== null){
        posterior= nuevoNodo;
    }else{
    nuevoNodo.sgte = posterior;
    
    posterior= nuevoNodo;
    }
    contador --;
    
    
       return null;
    
} 

    @Override
    public int getSize() {
         return contador;
         }

    @Override
    public Object frente() {
        Nodo aux = posterior;
       
        
       
    
       
           
         return aux.element;
         
    }

    
     public String toString(){
     Nodo aux = posterior;
        
        while(aux != null){
            System.out.println("|\t" + aux.element + "\t|");
            System.out.println("-----------------");
            aux = aux.sgte;}
         return null;
     }
    public void destroy(){
        posterior=null;
        contador= 0;
    }
        
}
