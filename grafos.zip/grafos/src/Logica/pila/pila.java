/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Logica.pila;

/**
 *
 * @author Allan Rodriguez
 */
public interface pila {
    public int getSize();
    public boolean isEmpty ();
    public Object top  () throws Pilaexception ;
    public Object pop ()throws Pilaexception ;
    public void push (Object element);
}
