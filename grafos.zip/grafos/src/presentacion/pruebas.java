/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package presentacion;

import logico.grafo.GrafoAdyancencia;

/**
 *
 * @author Allan Rodriguez
 */
public class pruebas {
    GrafoAdyancencia vs;
    
    public pruebas(int n){
         vs = new GrafoAdyancencia(n);
    }
    public void test(){
  
    
    vs.agregarVertice("San Jose");
    vs.agregarVertice("Alajuela");
    vs.agregarVertice("Heredia");
    vs.agregarVertice("Limon");
    vs.agregarVertice("Guanacaste");
    vs.agregarVertice("Cartago");
    vs.agregarVertice("Puntarenas");
    
   
    
    vs.agregarArista("San Jose","Alajuela");
    vs.agregarArista("Heredia","Limon");
    vs.agregarArista("Guanacaste","Cartago");
    vs.agregarArista("Alajuela","Heredia");
    vs.agregarArista("San Jose","Guanacaste");
    
   

    vs.agregarPeso("San Jose","Alajuela",10);
    vs.agregarPeso("Heredia","Limon",60);
    vs.agregarPeso("Guanacaste","Cartago",160);
    vs.agregarPeso("Alajuela","Heredia",41);
    vs.agregarPeso("San Jose","Guanacaste",150);
   
  
   
   
     
        
     
    System.out.println(vs.toString());    
    
   
        
    }
    
}
